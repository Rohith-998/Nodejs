const express=require('express');
const helmet=require('helmet');
const xss=require('xss-clean')
const userRouter=require('./Routes/userRoute');
const rateLimit=require('express-rate-limit');
const app=express();

const limiter=rateLimit({

max:100,
windowMs:60*60*1000,
message:'Too Many request please try after an hour',
headers: true,


})
app.use(helmet());
app.use('/api',limiter);
app.use(express.json({limit:'16kb'}));
app.use(xss());
app.use('/api/v1/user',userRouter);

module.exports=app;