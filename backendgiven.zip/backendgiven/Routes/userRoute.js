const express=require('express');
const rateLimit=require('express-rate-limit');
const usercontroller=require('../Controller/usercontroller');
const userRoute=express.Router();
const limiter=rateLimit({

    max:1,
    windowMs:60 * 1000,
    message:'Only one request per Cilent to acess the file try after 60 seconds',
    headers: true,
    
    
    })
userRoute.route('/').post(limiter,usercontroller.createUser).get(usercontroller.getAllUsers)
userRoute.route('/:id').get(usercontroller.getone).delete(usercontroller.deleteUser)
module.exports=userRoute