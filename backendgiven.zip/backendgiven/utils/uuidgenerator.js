module.exports=() => {

let arr=[];
const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
const characterlen=chars.length;

const len=32;


for(let i=0;i<len;i++){


arr[i]=chars.charAt(Math.floor(Math.random() * characterlen))


}

return arr.join('');

}