const jwt=require('jsonwebtoken');
const genuuid=require('../utils/uuidgenerator');
const fs=require('fs');
const create=require('../server');



const creatFile=() => {

    if(process.argv[2]){

     
      return process.argv[2];


    }
else{

    return 'userdata.json'

}

}


fs.writeFileSync(`./dev-data/${creatFile()}`,'[]','utf-8')


const readfile=  JSON.parse(fs.readFileSync(`./dev-data/${creatFile()}`,'utf-8'));


const creatAndSendToken=(token,user,statuscode,res)=>{


const cookieOptions={

expires: new Date(Date.now() + process.env.COOKIE_EXP_IN * 24 * 60 * 60 * 1000 ),

httpOnly:true

}

res.cookie('jwt',token,cookieOptions);


res.status(statuscode).json({

    status:'success',
    token,
    data:user

    
    
    })

}

//CreatUser
exports.createUser=(req,res)=>{



try{
const key=genuuid()

readfile.forEach(ele => {

if(Object.getOwnPropertyNames(ele)===key){

    console.log("this is true")

}
else{
console.log("this is else ")

}

});

const token=jwt.sign({id:key},process.env.JWT_SCR,{
expiresIn:process.env.EXP_IN,


},{
    algorithm: "HS256"
})
req.body.token=token;
const newUserObj={[key]:req.body};

readfile.push(newUserObj);
fs.writeFile(`./dev-data/${creatFile()}`,JSON.stringify(readfile),err => {

    creatAndSendToken(token,newUserObj,201,res);


})

}

catch(err){


    res.status(404).json({

        status:'fail',
        message:err,
    
        
        
        })


}

}

//GET ALL USERS

exports.getAllUsers=(req,res) => {

  

try{

    res.status(200).json({

        status: 'sucesss',
        data:readfile
    
    })
    
    }



catch(err){

    
    res.status(404).json({

        status: 'fail',
      message:err
    
    })
    
    
}

}
//GET SINLGE  USER
exports.getone=(req,res) => {
   
   
try{
   
const id=req.params.id;


 const getUser=readfile.find((element) => {
   
     
        return element[id]
        
  });



if(getUser!==undefined){
res.status(200).json({

status:'success',
data:getUser


})
}
else{
throw 'The user does not exsist'

}
}


catch(err){

    res.status(404).json({

        status:'fail',
        message:err
        
        
        })

}

}

exports.deleteUser=(req,res) => {

const deleteid=req.params.id;

    try{

      const getdeleted= readfile.findIndex(ele => {

           return   ele[deleteid];
           

        })


if(getdeleted>-1){

readfile.splice(getdeleted,1)




            fs.writeFile(`./dev-data/${creatFile()}`,JSON.stringify(readfile),err => {

                res.status(204).json({
            
                    status:'success',
                    
                    data:null
                
                    
                    
                    })
            
            
            })
        }
else{
throw 'the user is not avaliabel for deletion'

}

    }

    catch(err){

        res.status(404).json({

            status:'fail',
        message:err
            
            
            })

    }



}